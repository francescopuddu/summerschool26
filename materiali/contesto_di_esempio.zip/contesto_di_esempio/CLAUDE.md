L'utente di questa sessione è Sara Ferri, Project Manager del progetto di monitoraggio flussi passeggeri ferroviari Nord Italia presso Iridia Solutions S.p.A.
